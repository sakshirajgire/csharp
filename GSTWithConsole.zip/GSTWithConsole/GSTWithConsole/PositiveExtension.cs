﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter10
{
    public static class PositiveExtension
    {
        public static bool IsPositive(this int i, int value)
        {
            if (i >= 0)
            {
                Console.WriteLine(i + value);
                return true;
            }
            else
            {
                Console.WriteLine("No is negative");
                return false;
            }
        }
    }
    class PExtension
    {
        static void Main()
        {
            Console.WriteLine("Enter no");

            int i = Convert.ToInt32(Console.ReadLine());
            bool result = i.IsPositive(25);

        }
    }
}
