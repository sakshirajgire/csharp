﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GST;

namespace GSTWithConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            double gstamt;
            Console.WriteLine("Enter Product Amount");
            double pamt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Percentage");
            double perc = Convert.ToDouble(Console.ReadLine());
            GSTSLAB gstlab = new GSTSLAB(perc,pamt);
            //Console.WriteLine($"Total Amount { gstlab.CalculateGST(out double gstamt,pamt,perc)}");
            Console.WriteLine("Total Amount after GST {0}", gstlab.CalculateGST(out gstamt, pamt, perc));
            Console.WriteLine("GST amount is {0}", gstamt);
            Console.ReadLine();
        }
    }
}
