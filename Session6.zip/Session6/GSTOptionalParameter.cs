﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments
{
    class GSTOptionalParameter
    {
        static void Main()
        {
            AllFunctions gstamt = new AllFunctions();          
            Console.WriteLine("Enter the amount");
            int amt = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Do you want to enter gst amount(y|n)");
            char c = Convert.ToChar(Console.ReadLine());
            if (c == 'y')
            {
                Console.WriteLine("Enter the gst percentage");
                int gstper = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Total Amount after GST {0}", gstamt.CalulateGST(amt, gstper));
            }
            else
            {
                Console.WriteLine("Total Amount after GST {0}", gstamt.CalulateGST(amt));
            }
            Console.ReadLine();

        }
    }
}
