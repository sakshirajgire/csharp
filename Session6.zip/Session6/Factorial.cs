﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments
{
    class Factorial
    {
        static void Main()
        {
            Console.WriteLine("Enter the no");
            int num = Convert.ToInt32(Console.ReadLine());
            AllFunctions fact = new AllFunctions();
            int factorial=fact.Fact(num);
            Console.WriteLine($"Factorial: {factorial} ");
            Console.ReadLine();
        }
    }
}
