﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments
{
    class SimpleIntUsingOut
    {
        static void Main()
        {

            AllFunctions simpleInterest = new AllFunctions();
            Console.WriteLine("Enter the Principal amount");
            double pamt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the rate of Interest");
            double rate = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the no of years");
            int year = Convert.ToInt32(Console.ReadLine());
            double sinterest;
            double TotalPayable = simpleInterest.SimpleInterestOut(out sinterest, pamt, rate, year);
            Console.WriteLine($"Simple Interest:{sinterest}");
            Console.WriteLine($"Total Payable Amount{TotalPayable}");
            Console.ReadLine();
        }
    }
}
