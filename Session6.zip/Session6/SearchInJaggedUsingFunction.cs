﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments
{
    class SearchInJaggedUsingFunction
    {
        static void Main()
        {
            AllFunctions searchele = new AllFunctions();
            int[][] nums = new int[2][];
            nums[0] = new int[3] { 10, 20, 30 };
            nums[1] = new int[2] { 40, 50 };
            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in nums[i])
                {

                    Console.WriteLine("{0}\t", temp);
                }
            }
            Console.WriteLine("Enter the element to be searched");
            int ele = Convert.ToInt32(Console.ReadLine());
            int index = searchele.SearchElement(ele);            
            if(index>=0)
            {
                Console.WriteLine($"Element Found at{index}");
            }
            else
            {
                Console.WriteLine("Element Not found");
            }
            Console.ReadLine();
        }
    }
}
