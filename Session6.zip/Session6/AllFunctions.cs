﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments
{
    class AllFunctions
    {
        public int Fact(int num)
        {
            int fact = 1;
            for(int i=1;i<=num;i++)
            {
                fact = fact * i;
            }
            return fact;
        }
        public int SearchElement(int No)
        {
            int[][] nums = new int[2][];
            nums[0] = new int[3] { 10, 20, 30 };
            nums[1] = new int[2] { 40, 50 };
            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in nums[i])
                {
                    if (No == temp)
                    {
                        //Console.WriteLine(temp);
                        return i;
                    }

                }
              
            }
            return 0;

        }
        public double SimpleInterest(double PAmt,double Rate,int Year)
        {
            double SI = 0;
            SI = PAmt * Rate * Year / 100;
            return SI;
        }
        public double SimpleInterestOut(out double sinterest, double PAmt, double Rate, int Year)
        {
            
            double SI = 0;
            SI = PAmt * Rate * Year / 100;
            sinterest = SI;
            return (PAmt + SI);
        }
        public double CalulateGST(double productamt, int gstper=1)
        {
            return productamt * gstper / 100;
        }
    }
}
