﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//WAP to Calculate area of circle.
namespace Chapter2
{
    class AreaofCircle
    {
        static void Main()
        {
            Console.WriteLine("Enter the radius of cirle");
            int r = Convert.ToInt32(Console.ReadLine());
            const double PI = 3.14;
            double aoc = r * r * PI;
            Console.WriteLine(aoc);
            Console.ReadLine();
        }
    }
}

