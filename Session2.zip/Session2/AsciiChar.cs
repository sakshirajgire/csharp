﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
    {
        class AsciiChar
        {
            static void Main()
            {

                Console.WriteLine("Enter the character");
                char c = Convert.ToChar(Console.ReadLine());
                //char c = 'A';
                int ascii = (int)c;
                Console.WriteLine(ascii);
                Console.WriteLine("Enter the ascii value");
                int val = Convert.ToInt32(Console.ReadLine());
                char s = (char)val;
                Console.WriteLine(s);
                Console.ReadLine();
            }
        }
    }

