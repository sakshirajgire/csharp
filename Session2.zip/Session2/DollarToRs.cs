﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class DollarToRs
    {
        static void Main()
        {
            Console.WriteLine("Enter the amount to convert");
            double amt = Convert.ToDouble(Console.ReadLine());
            //double amt = 500;
            decimal dollar = (decimal)amt / 70;
            Console.WriteLine("Rupees To Dollar={0}", dollar);
            int rs = Convert.ToInt32(dollar * 70);
            Console.WriteLine("Dollar to ruppes={0}", rs);
            Console.ReadLine();

        }
    }
}
