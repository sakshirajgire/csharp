﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments.Session8
{
    
     class SavingAccount: IBankAccount
    {
        double Balance = 2000;
        public void Deposit(double amount)
        {
            Balance = Balance + amount;
            Console.WriteLine($"Total Account Balance {Balance}");
        }
        public void Withdraw(double amount)
        {
            Balance = Balance - amount;
            Console.WriteLine($"Total Account Balance {Balance}");
        }
    }
    class CurrentAccount:IBankAccount
    {
        double Balance = 5000;
        public void Deposit(double amount)
        {
            Balance = Balance + amount;
            Console.WriteLine($"Total Account Balance {Balance}");
        }
        public void Withdraw(double amount)
        {
            Balance = Balance - amount;
            Console.WriteLine($"Total Account Balance {Balance}");
        }
    }
   
    class Account_MainMethod
    {
        static void Main()
        {
            SavingAccount sa = new SavingAccount();
            CurrentAccount ca = new CurrentAccount();
            Console.WriteLine("Select your Account");
            Console.WriteLine("1.Saving");
            Console.WriteLine("2.Current");
            int choice = Convert.ToInt32(Console.ReadLine());
            
            if(choice==1)
            {
                Console.WriteLine("Deposit or Withdrwa(D|W)");
                char c = Convert.ToChar(Console.ReadLine());
                if(c=='d' || c=='D')
                {
                    Console.WriteLine("Enter the Amount to be deposited");
                    double amt = Convert.ToInt32(Console.ReadLine());
                    sa.Deposit(amt);
                }
                else if(c== 'w' || c=='W' )
                {
                    Console.WriteLine("Enter the Amount to be Withdraw");
                    double amt = Convert.ToInt32(Console.ReadLine());
                    sa.Withdraw(amt);
                }
                else
                {
                    Console.WriteLine("Invalid Choice");
                }
            }
           else if(choice==2)
            {
                Console.WriteLine("Deposit or Withdrwa(D|W)");
                char c = Convert.ToChar(Console.ReadLine());
                if (c == 'd' || c == 'D')
                {
                    Console.WriteLine("Enter the Amount to be deposited");
                    double amt = Convert.ToInt32(Console.ReadLine());
                    sa.Deposit(amt);
                }
                else if (c == 'w' || c == 'W')
                {
                    Console.WriteLine("Enter the Amount to be Withdraw");
                    double amt = Convert.ToInt32(Console.ReadLine());
                    sa.Withdraw(amt);
                }
                else
                {
                    Console.WriteLine("Invalid Choice");
                }
            }
            else
            {
                Console.WriteLine("Invalid Choice");
            }

            Console.ReadLine();
        }
    }
}
