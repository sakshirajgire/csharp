﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments.Session8
{
    sealed class SealedClass
    {
        public string StartWriting()
        {
            return "This is Start Writing";
        }
        public string StopWriting()
        {
            return "This is StopWriting";
        }
    }
    public class Sealed_MainMethod
    {
        static void Main()
        {
            SealedClass sc = new SealedClass();
            Console.WriteLine(sc.StartWriting());
            Console.WriteLine(sc.StopWriting());
        }
    }
}
