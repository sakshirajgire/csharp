﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments.Session8
{
    class Requirements
    {
        long _id;
        string _name;
        string _emailid;
        string _dateofBirth;
        public Requirements()
        {
            Console.WriteLine("This is Default Constructor of Requirements");

        }
        public Requirements(long _id,string _name,string _emailid, string _dateofBirth)
        {
            this._id = _id;
            this._emailid = _emailid;
            this._name = _name;
            this._dateofBirth = _dateofBirth;
        }
        public override string ToString()
        {
            return string.Format("Id={0}\nName={1}\nEmailId={2}\nDate of Birth={3}\n", _id, _name, _emailid, _dateofBirth);
        }
        public static bool IsEmailDuplicate(List<Requirements> items,string mail)
        {
            foreach(var temp in items)
            {
                if(temp._emailid==mail)
                {
                    return true;
                }
            }
            return false;
        }
       
        static void Main()
        {
           
            List<Requirements> mylist = new List<Requirements>();
            int choice;
            do
            {
               
                Console.WriteLine("Enter User Id");
                long _id = Convert.ToInt64(Console.ReadLine());
                Console.WriteLine("Enter User Name");
                string _name = Console.ReadLine();
                Console.WriteLine("Enter User Emailid");
                string _emailid = Console.ReadLine();
                bool result = IsEmailDuplicate(mylist, _emailid);
                while (result)
                {
                    Console.WriteLine("Email Id not available");
                    _emailid = Console.ReadLine();
                    result = IsEmailDuplicate(mylist, _emailid);
                }
                Console.WriteLine("Enter Date of Birth");
                string _dateofBirth = Console.ReadLine();
                Requirements item = new Requirements(_id, _name, _emailid, _dateofBirth);
                Console.WriteLine("User Details");
                Console.Write(item.ToString());// Overriden ToString Method
                Console.WriteLine("Do you want to add more users");
                Console.WriteLine("1.Add\n2.Exit");
                choice = Convert.ToInt32(Console.ReadLine());

                mylist.Add(item);

            } while (choice!=2);

            Console.ReadLine();
        }

        
    }
}
