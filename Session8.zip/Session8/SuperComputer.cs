﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments.Session8
{
     class SuperComputer:Computer
    {
        public string Super()
        {
            return "Derived SuperComputer";
        }
    }
    class MainframeComputer : Computer
    {
        public string MainFrame()
        {
            return "Derived MainframeComputer";
        }
    }
    class MicroComputer : Computer
    {
        public string Micro()
        {
            return "Derived MicroComputer";
        }
    }
    class Main_Method
    {
        static void Main()
        {
            SuperComputer sc = new SuperComputer();
            MainframeComputer mc = new MainframeComputer();
            MicroComputer m = new MicroComputer();
            Console.WriteLine(sc.Super());
            Console.WriteLine(mc.MainFrame());
            Console.WriteLine(m.Micro());
        }
    }
}
