﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments.Session8
{
    class Room
    {
        int _number;
        int _floor;
        string _type;
        int _capacity;
        DateTime _bookedtime;
        double _price;
        public Room()
        {
            Console.WriteLine("Default Constructor of Hotel Room");
        }
        public Room(int _number, int _floor, string _type, int _capacity, DateTime _bookedtime, double _price)
        {
            this._number = _number;
            this._floor = _floor;
            this._type = _type;
            this._price = _price;
            this._capacity = _capacity;
            this._bookedtime = _bookedtime;
           
        }
        public override string ToString()
        {
            return string.Format("Number={0}\n Floor={1}\n Type={2}\n Capacity={3}\n Booked Time={4}\n Price={5}\n", _number, _floor, _type, _capacity, _bookedtime, _price);
        }
    }
    class HotelRoomProperties
    {
        private int number;
        public int _number
        {
            get
            {
                return number;
            }
            set
            {
                number = value;
            }
        }
        public int _floor { get; set; }
        public string _type { get; set; }
        public DateTime _bookedtime { get; set; }
        public int _capacity { get; set; }
        public double _price { get; set; }
    }
    class HotelRoom_MainMethod
    {
        static void Main()
        {
           
                Console.WriteLine("Enter Hotel Room No");
                int rno = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Room type ");
                string rtype = Console.ReadLine();
                Console.WriteLine("Enter Booked Time(hh:mm:ss)");
                DateTime btime = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Hotel Capacity");
                int capacity = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Floor");
                int floor = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Room Price");
                double price = Convert.ToDouble(Console.ReadLine());
                Room room = new Room(rno, floor, rtype, capacity, btime, price);
                Console.Write(room.ToString());
            
            Console.ReadLine();

        }
    }
}
