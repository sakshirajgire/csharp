﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Write a program to display numbers in reverse order from 50 to 1 using for loop construct.
namespace Assigments
{
    class PrintReverse
    {
        static void Main()
        {
            for(int i=50;i>=1;i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadLine();
        }
    }
}
