﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//
namespace Assigments
{
    class EvenNoUsingForEach
    {
        static void Main()
        {
            int[] nos = new int[50];
            Console.WriteLine("Enter array elements");           
            for (int i = 1; i <= 5; i++)
            {
                nos[i] = Convert.ToInt32(Console.ReadLine());
            }
            
            Console.WriteLine("Even no");
            foreach (int temp in nos)
            {
                if (temp % 2 == 0 && temp > 1 && temp <= 50)
                {
                    Console.WriteLine(temp);
                }
            }
            Console.ReadLine();
        }
    }
}
