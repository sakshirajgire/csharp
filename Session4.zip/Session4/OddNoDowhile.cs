﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Write a program to display odd nos between 1 to 50 using do while loop.
namespace Assigments
{
    class OddNoDowhile
    {
        static void Main()
        {
            Console.WriteLine("Odd Nos from 1 to 50");
            int i = 1;
            do
            {
                if (i % 2 != 0)
                {
                    Console.WriteLine(i);
                }
               
                i++;
            } while( i<=50);           
            Console.ReadLine();
        }
    }
}
