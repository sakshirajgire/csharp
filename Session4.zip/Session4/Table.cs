﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Write a program to print table of given number using for loop.
namespace Assigments
{
    class Table
    {
        static void Main()
        {
            Console.WriteLine("Enter the no");
            int no = Convert.ToInt32(Console.ReadLine());
            for(int i=1;i<=10;i++)
            {
                Console.WriteLine("{0}*{1} ={2}",no,i,i* no);
            }
            Console.ReadLine();
        }
    }
}
