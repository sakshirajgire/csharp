﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Write a program to display odd nos between 1 to 50 using foreach from given array.
namespace Assigments
{
    class OddNoUsingForEach
    {
        static void Main()
        {
            int[] nos = new int[50];           
            Console.WriteLine("Odd Nos from 1 to 50");          
           
            for (int i = 1; i <= 5; i++)
            {
                    nos[i] = Convert.ToInt32(Console.ReadLine());
            }
          
            Console.WriteLine("Odd nos");
            foreach (int temp in nos)
            {
                if (temp % 2 != 0 && temp > 1 && temp <=50)
                {
                    Console.WriteLine(temp);
                }
            }
            Console.ReadLine();
        }
    }
}
