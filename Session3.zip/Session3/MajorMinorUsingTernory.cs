﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Develop a program to decide whether a person is major or minor using Ternary operator.
namespace Assigments
{
    class MajorMinorUsingTernory
    {
        static void Main()
        {
            Console.WriteLine("Enter the age of person");
            int age = Convert.ToInt32(Console.ReadLine());
            string result=age >= 18 ? "Major" : "Minor" ;

            Console.WriteLine(result);
            Console.ReadLine();
        }
    }
}
