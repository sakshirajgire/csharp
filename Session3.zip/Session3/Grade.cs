﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Develop a program to decide grade according to percentage using if-else if-else.
namespace Assigments
{
    class Grade
    {
        static void Main()
        {
            Console.WriteLine("Enter the Percentage");
            int Percentage = Convert.ToInt32(Console.ReadLine());
            if(Percentage>=80)
            {
                Console.WriteLine("Outstanding(O)");
            }
            else if (Percentage >=70&& Percentage <= 79)
            {
                Console.WriteLine("A+");
            }
            else if (Percentage >= 60 && Percentage <= 69)
            {
                Console.WriteLine("A");
            }
            else if (Percentage >= 50 && Percentage <= 59)
            {
                Console.WriteLine("B+");
            }
            else if (Percentage >= 45 && Percentage <= 49)
            {
                Console.WriteLine("B");
            }
            else if (Percentage >= 40 & Percentage <= 44)
            {
                Console.WriteLine("C");
            }
            else if (Percentage<40)
            {
                Console.WriteLine("Fail");
            }
            Console.ReadLine();
        }
    }
}
