﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments
{
    class AsciiCode
    {
        static void Main()
        {
            char[,] character = new char[,] { { 'a','b','c' }, { 'd', 'e', 'f' }, { 'g', 'h', 'i' } };
            int[,] nos = new int[3,3];
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", character[i, j]);

                }
                Console.WriteLine();
            }
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    
                    Console.Write("{0}\t", (int)character[i, j]);

                }
                Console.WriteLine();
            }
            
            Console.ReadLine();
        }
    }
}
