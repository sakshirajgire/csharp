﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments
{
    class SearchInJagged
    {
        static void Main()
        {
            int[][] nums = new int[2][];
            nums[0] = new int[3] { 10, 20, 30 };
            nums[1] = new int[2] { 40, 50 };
            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in nums[i])
                {

                    Console.WriteLine("{0}\t", temp);
                }
            }
            Console.WriteLine("Enter the element to be searched");
            int ele = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in nums[i])
                {
                    if (ele == temp)
                    {
                        Console.WriteLine("Element found");
                    }
                    else 
                    {
                        Console.WriteLine("Element found");
                        break;
                    }
                }
               
            }

            Console.ReadLine();
        }
    }
}
