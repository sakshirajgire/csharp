﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments
{
    class SumSingleDimArray
    {
        static void Main()
        {
            int[] nos = new int[5];
            int sum = 0;
            Console.WriteLine("Enter the array");
            for(int i=1;i<5;i++)
            {
                 nos [i]=Convert.ToInt32(Console.ReadLine());
                sum = sum + nos[i];

            }
            Console.WriteLine("Sum of Array {0}", sum);
            Console.ReadLine();
        }
        

    }
}
