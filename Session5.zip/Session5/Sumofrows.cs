﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments
{
    class Sumofrows
    {
        static void Main()
        {
            int[,] nums1 = new int[,] { { 10, 40, 50 }, { 60, 20, 70 }, { 80, 90, 30 } };
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", nums1[i, j]);

                }
                Console.WriteLine("\n");

            }
            int sum = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    sum = sum + nums1[i, j];
                }
                Console.WriteLine("Sum of Diagonals {0}", sum);
                sum = 0;
            }
            Console.ReadLine();
        }
        
    }
}
