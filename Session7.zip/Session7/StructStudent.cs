﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments
{
    class StructStudent
    {
    }
    struct Student
    {
        int RollNo;
        string Name;
        string Gender;
        string MobileNo;
        public Student(int RollNo, string Name, string Gender, string MobileNo)
        {
            this.RollNo = RollNo;
            this.Name = Name;
            this.Gender = Gender;
            this.MobileNo = MobileNo;
        }
        public string Display(int rollno, string name,string gender,string marks)
        {
            return string.Format("rollno={0} Name={1} gender={2} marks={3}", rollno, name, gender, marks);
        }
    }
}
