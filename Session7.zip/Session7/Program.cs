﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments
{
    class Program
    {
        static void Main(string[] args)
        {
            Student std = new Student();
            Console.WriteLine("Enter Student Roll No");
            int rollno = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Student Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Student Gender");
            string gender = Console.ReadLine();
            Console.WriteLine("Enter Student Marks");
            string marks = Console.ReadLine();
            Console.WriteLine(std.Display(rollno, name, gender, marks));            
            Console.ReadLine();
        }
    }
}
