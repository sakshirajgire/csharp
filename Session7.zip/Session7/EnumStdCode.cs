﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments
{
    class EnumStdCode
    {
        static void Main()
        {

            //Console.WriteLine(GST.Maharashtra.GetHashCode());
            Console.WriteLine("City Names");
            foreach (string name in Enum.GetNames(typeof(StdCode)))
            {
                Console.WriteLine(name);
            }
            Console.WriteLine("City Codes");
            foreach (int Code in Enum.GetValues(typeof(StdCode)))
            {
                Console.WriteLine(Code);
            }
            Console.ReadLine();

        }
    }
}
