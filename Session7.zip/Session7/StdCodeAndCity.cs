﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigments
{
    class StdCodeAndCity
    {
    }
    enum StdCode
    {
      Pune=020,Mumbai=022,Amravati=0721,Aurangabad=011
    }
}
